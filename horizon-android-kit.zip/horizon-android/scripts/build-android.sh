#!/usr/bin/env bash
# Build the Horizon APK.
#   scripts/build-android.sh /path/to/horizon-checkout [--no-gradle]
# Needs: `rustup target add aarch64-linux-android`, cargo-ndk, Android NDK (ANDROID_NDK_HOME),
#        JDK 17, python3, and gradle 8.10+ for the last step (or open android/ in Android Studio).
set -euo pipefail

HZ="${1:?usage: build-android.sh <horizon-checkout> [--no-gradle]}"
HZ="$(cd "$HZ" && pwd)"
KIT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
: "${ANDROID_NDK_HOME:?set ANDROID_NDK_HOME to the NDK folder (r26 or newer)}"

echo "==> patching Horizon"
python3 "$KIT/scripts/patch_horizon.py" "$HZ"

echo "==> cargo ndk (arm64-v8a)"
cd "$HZ"
export RUSTFLAGS="${RUSTFLAGS:-} --cap-lints warn -C link-arg=-Wl,-z,max-page-size=16384"
cargo ndk --platform 29 -t arm64-v8a rustc --release -p horizon-client --bin horizon-client -- --crate-type cdylib

SO="$(find target/aarch64-linux-android/release -maxdepth 2 -name 'libhorizon_client*.so' -printf '%T@ %p\n' | sort -n | tail -n 1 | cut -d' ' -f2-)"
[ -n "$SO" ] || { echo "libhorizon_client.so not found under target/aarch64-linux-android/release" >&2; exit 1; }
JNI="$KIT/android/app/src/main/jniLibs/arm64-v8a"
mkdir -p "$JNI"
cp "$SO" "$JNI/libhorizon_client.so"
echo "    $SO -> $JNI/libhorizon_client.so"

TOOLS="$(echo "$ANDROID_NDK_HOME"/toolchains/llvm/prebuilt/*/bin)"
if [ -x "$TOOLS/llvm-readelf" ] && "$TOOLS/llvm-readelf" -d "$JNI/libhorizon_client.so" | grep -q 'libc++_shared'; then
  cp "$(echo "$ANDROID_NDK_HOME"/toolchains/llvm/prebuilt/*/sysroot/usr/lib/aarch64-linux-android/libc++_shared.so)" "$JNI/"
  echo "    + libc++_shared.so"
fi
if [ -x "$TOOLS/llvm-strip" ]; then "$TOOLS/llvm-strip" --strip-unneeded "$JNI/libhorizon_client.so" || true; fi

if [ "${2:-}" = "--no-gradle" ]; then echo "done (native part only)"; exit 0; fi
echo "==> gradle assembleDebug"
cd "$KIT/android"
gradle --no-daemon assembleDebug
echo "APK: $KIT/android/app/build/outputs/apk/debug/app-debug.apk"
