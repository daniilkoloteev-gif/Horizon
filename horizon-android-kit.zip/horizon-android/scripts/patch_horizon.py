#!/usr/bin/env python3
"""Patch a checkout of horizon-rust/horizon so that `horizon-client` builds for Android.

    python3 scripts/patch_horizon.py /path/to/horizon [--dry-run]

Idempotent. Every change is visible with `git diff` inside the checkout.

  1. copies rust/android_glue.rs.tmpl to crates/horizon-client/src/android_glue.rs
  2. adds `mod android_glue;` and the `android_main` entry point
  3. routes EventLoop creation and std::env::args() through the glue
  4. (best effort) turns winit Touch events into mouse events in `window_event`
  5. adds the Android-only dependencies to crates/horizon-client/Cargo.toml

The script only knows winit 0.29 / 0.30. When it cannot find a spot it needs, it
stops with a message instead of guessing.
"""
from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

KIT = Path(__file__).resolve().parent.parent
TAG = "horizon-android-kit"
ENTRY_MARK = f"// {TAG}: module and entry point"
CARGO_MARK = f"# --- {TAG}"


class Fail(Exception):
    pass


def say(kind: str, msg: str) -> None:
    print(f"[{kind}] {msg}")


PFX = r"(?:winit::(?:event_loop::)?)?"
RE_EL_NEW = re.compile(r"\b" + PFX + r"EventLoop::new\(\)")
RE_EL_BUILDER = re.compile(r"\b" + PFX + r"EventLoop::builder\(\)")
RE_ELB_NEW = re.compile(r"\b" + PFX + r"EventLoopBuilder::new\(\)")
RE_UE_EL = re.compile(r"\b" + PFX + r"EventLoop::<(.+?)>::with_user_event\(\)")
RE_UE_ELB = re.compile(r"\b" + PFX + r"EventLoopBuilder::<(.+?)>::with_user_event\(\)")
RE_UE_BARE = re.compile(r"\bEventLoop(?:Builder)?::with_user_event\(\)")
RE_ARGS = re.compile(r"\b(?:std::)?env::args\(\)")
RE_MOD = re.compile(r"^[ \t]*(?:pub(?:\([^)]*\))?[ \t]+)?mod[ \t]+(\w+)[ \t]*;", re.M)
RE_WINDOW_EVENT = re.compile(
    r"fn\s+window_event\s*\(\s*&mut\s+self\s*,\s*"
    r"(?P<el>\w+)\s*:\s*&\s*(?:winit::event_loop::)?ActiveEventLoop\s*,\s*"
    r"(?P<wid>\w+)\s*:\s*(?:winit::window::)?WindowId\s*,\s*"
    r"(?P<ev>\w+)\s*:\s*(?:winit::event::)?WindowEvent\s*,?\s*\)\s*\{",
    re.S,
)


def detect_winit(repo: Path):
    lock = repo / "Cargo.lock"
    if not lock.exists():
        return None
    text = lock.read_text(encoding="utf-8")
    found = [
        tuple(int(x) for x in m.groups())
        for m in re.finditer(r'\[\[package\]\]\r?\nname = "winit"\r?\nversion = "(\d+)\.(\d+)\.(\d+)', text)
    ]
    return max(found) if found else None


def patch(repo: Path, dry: bool) -> int:
    client = repo / "crates" / "horizon-client"
    cargo_path = client / "Cargo.toml"
    src = client / "src"
    main_rs = src / "main.rs"
    lib_rs = src / "lib.rs"
    for p in (cargo_path, main_rs):
        if not p.exists():
            raise Fail(f"{p} не найден. Это точно чекаут horizon-rust/horizon?")

    writes: dict[Path, str] = {}

    def cur(p: Path) -> str:
        return writes[p] if p in writes else p.read_text(encoding="utf-8")

    def put(p: Path, text: str) -> None:
        if p.exists() and p.read_text(encoding="utf-8") == text:
            writes.pop(p, None)
        else:
            writes[p] = text

    cargo = cur(cargo_path)

    # ---- winit ---------------------------------------------------------------
    if not re.search(r"^\s*winit\b", cargo, re.M):
        raise Fail(
            "horizon-client не зависит от winit напрямую (нет строки `winit = ...` в "
            "crates/horizon-client/Cargo.toml). Нужна ручная интеграция."
        )
    ver = detect_winit(repo)
    if ver is None:
        raise Fail("не нашёл winit в Cargo.lock (нужен Cargo.lock в корне чекаута).")
    if ver[:2] == (0, 30):
        flavor, req = "0.30", "0.30"
    elif ver[:2] == (0, 29):
        flavor, req = "0.29", "0.29"
    else:
        raise Fail(f"winit {ver[0]}.{ver[1]}.{ver[2]}: патчер знает только 0.29 и 0.30.")
    say("ok", f"winit {ver[0]}.{ver[1]}.{ver[2]} -> API {flavor}")

    # ---- crate layout ----------------------------------------------------------
    has_lib = lib_rs.exists()
    pkg = re.search(r'^\s*name\s*=\s*"([^"]+)"', cargo, re.M)
    lib_name = (pkg.group(1) if pkg else "horizon-client").replace("-", "_")
    m = re.search(r'^\[lib\][^\[]*?^\s*name\s*=\s*"([^"]+)"', cargo, re.M | re.S)
    if m:
        lib_name = m.group(1).replace("-", "_")
    lib_mods = set(RE_MOD.findall(cur(lib_rs))) if has_lib else set()
    main_mods = set(RE_MOD.findall(cur(main_rs)))
    say("ok", "раскладка: " + (f"lib ({lib_name}) + bin" if has_lib else "только bin"))

    def top_stem(p: Path) -> str:
        top = p.relative_to(src).parts[0]
        return top[:-3] if top.endswith(".rs") else top

    def belongs(p: Path) -> bool:
        return top_stem(p) in ({"main", "lib"} | lib_mods | main_mods)

    def glue_prefix(p: Path) -> str:
        s = top_stem(p)
        if not has_lib or s == "lib" or s in lib_mods:
            return "crate::android_glue::"
        return f"{lib_name}::android_glue::"

    # ---- 1. glue file ------------------------------------------------------------
    glue_dst = src / "android_glue.rs"
    tmpl = (KIT / "rust" / "android_glue.rs.tmpl").read_text(encoding="utf-8")
    if flavor == "0.30":
        nb, nbu = "EventLoop::builder()", "EventLoop::<T>::with_user_event()"
    else:
        nb, nbu = "EventLoopBuilder::new()", "EventLoopBuilder::<T>::with_user_event()"
    put(glue_dst, tmpl.replace("@@NEW_BUILDER_USER@@", nbu).replace("@@NEW_BUILDER@@", nb))

    # ---- 2. module + android_main ----------------------------------------------------
    main_txt = cur(main_rs)
    if ENTRY_MARK not in main_txt:
        add = f"\n{ENTRY_MARK} (scripts/patch_horizon.py)\n"
        if not has_lib:
            add += "mod android_glue;\n\n"
        add += (
            '#[cfg(target_os = "android")]\n'
            "#[unsafe(no_mangle)]\n"
            "fn android_main(app: winit::platform::android::activity::AndroidApp) {\n"
            f"    {glue_prefix(main_rs)}init(app);\n"
            "    let _ = main();\n"
            "}\n"
        )
        put(main_rs, main_txt.rstrip("\n") + "\n" + add)
    if has_lib:
        lib_txt = cur(lib_rs)
        if ENTRY_MARK not in lib_txt:
            put(lib_rs, lib_txt.rstrip("\n") + f"\n\n{ENTRY_MARK} (scripts/patch_horizon.py)\npub mod android_glue;\n")

    # ---- 3. event loop + args -----------------------------------------------------------
    files = sorted(p for p in src.rglob("*.rs") if p != glue_dst and belongs(p))
    n_el = n_args = 0
    bare = []
    for p in files:
        g = glue_prefix(p)
        text = cur(p)
        new, a = RE_EL_NEW.subn(lambda _m: f"{g}builder().build()", text)
        new, b = RE_EL_BUILDER.subn(lambda _m: f"{g}builder()", new)
        new, c = RE_ELB_NEW.subn(lambda _m: f"{g}builder()", new)
        new, d = RE_UE_EL.subn(lambda mm: f"{g}builder_user::<{mm.group(1)}>()", new)
        new, e = RE_UE_ELB.subn(lambda mm: f"{g}builder_user::<{mm.group(1)}>()", new)
        new, f = RE_ARGS.subn(lambda _m: f"{g}args()", new)
        if RE_UE_BARE.search(new):
            bare.append(p)
        n_el += a + b + c + d + e
        n_args += f
        if new != text:
            put(p, new)
    already = any("android_glue::builder" in cur(p) for p in files)
    if n_el == 0 and not already:
        hits = []
        for p in files:
            for i, line in enumerate(cur(p).splitlines(), 1):
                if "EventLoop" in line:
                    hits.append(f"    {p.relative_to(repo)}:{i}: {line.strip()}")
        raise Fail(
            "не нашёл, где создаётся EventLoop (на Android его нужно создавать через "
            "`.with_android_app(app)`). Кандидаты:\n" + ("\n".join(hits[:12]) or "    (ничего не найдено)")
        )
    say("ok", f"EventLoop: заменено мест: {n_el}" + (" (уже было пропатчено)" if already and n_el == 0 else ""))
    say("ok" if n_args else "skip", f"std::env::args(): заменено мест: {n_args}")
    for p in bare:
        say("warn", f"{p.relative_to(repo)}: EventLoop::with_user_event() без явного типа — замените вручную на "
                    f"{glue_prefix(p)}builder_user::<ТипСобытия>()")

    # ---- 4. touch -> mouse (best effort) -------------------------------------------------
    n_touch = 0
    for p in files:
        text = cur(p)
        if "touch_events(" in text or "ApplicationHandler" not in text:
            continue
        mm = RE_WINDOW_EVENT.search(text)
        if not mm:
            continue
        g = glue_prefix(p)
        line_start = text.rfind("\n", 0, mm.start()) + 1
        indent = re.match(r"[ \t]*", text[line_start:]).group(0) + "    "
        el, wid, ev = mm.group("el"), mm.group("wid"), mm.group("ev")
        ah = "winit::application::ApplicationHandler"
        block = (
            f'\n{indent}#[cfg(target_os = "android")]\n'
            f"{indent}{{\n"
            f"{indent}    if let winit::event::WindowEvent::Touch(touch) = &{ev} {{\n"
            f"{indent}        let out = {g}touch_events(touch);\n"
            f"{indent}        for synthetic in out.window_events {{\n"
            f"{indent}            {ah}::window_event(&mut *self, {el}, {wid}, synthetic);\n"
            f"{indent}        }}\n"
            f"{indent}        if let Some((dx, dy)) = out.look {{\n"
            f"{indent}            {ah}::device_event(\n"
            f"{indent}                &mut *self,\n"
            f"{indent}                {el},\n"
            f"{indent}                touch.device_id,\n"
            f"{indent}                winit::event::DeviceEvent::MouseMotion {{ delta: (dx, dy) }},\n"
            f"{indent}            );\n"
            f"{indent}        }}\n"
            f"{indent}        return;\n"
            f"{indent}    }}\n"
            f"{indent}}}\n"
        )
        put(p, text[: mm.end()] + block + text[mm.end():])
        n_touch += 1
    if n_touch:
        say("ok", f"touch -> мышь: вставлено в window_event: {n_touch}")
    elif any("touch_events(" in cur(p) for p in files):
        say("skip", "touch -> мышь: уже вставлено")
    else:
        say("warn", "не нашёл `fn window_event(&mut self, &ActiveEventLoop, WindowId, WindowEvent)` в impl ApplicationHandler: "
                    "тач-ввод не подключён (меню не будут реагировать на касания)")

    # ---- 5. Cargo.toml --------------------------------------------------------------------------
    if CARGO_MARK in cargo:
        say("skip", "Cargo.toml: уже пропатчен")
    elif re.search(r"""^\[target\.'cfg\(target_os = "android"\)'\.dependencies\]""", cargo, re.M):
        say("warn", "в Cargo.toml уже есть секция android-зависимостей: добавьте в неё вручную winit "
                    f'(version "{req}", features ["android-native-activity"]), android_logger, log, libc')
    else:
        block = (
            f"\n{CARGO_MARK} (scripts/patch_horizon.py) ---\n"
            "[target.'cfg(target_os = \"android\")'.dependencies]\n"
            f'winit = {{ version = "{req}", features = ["android-native-activity"] }}\n'
            'android_logger = "0.14"\n'
            'log = "0.4"\n'
            'libc = "0.2"\n'
        )
        put(cargo_path, cargo.rstrip("\n") + "\n" + block)

    # ---- warnings -----------------------------------------------------------------------------------
    sources = [cargo_path, repo / "Cargo.toml", main_rs, lib_rs]
    blob = "\n".join(cur(p) for p in sources if p.exists())
    if re.search(r'forbid\s*\(\s*unsafe_code\s*\)|unsafe_code\s*=\s*"forbid"', blob):
        say("warn", "найден forbid(unsafe_code): android_glue.rs использует unsafe (libc, set_var) — компиляция упадёт; "
                    "ослабьте до deny/allow в клиенте")
    if re.search(r"^\s*clap\b", cargo, re.M):
        say("warn", "клиент использует clap: он читает аргументы сам, launch-args.txt может не примениться")

    # ---- write ------------------------------------------------------------------------------------------
    if not writes:
        say("skip", "изменений нет: чекаут уже пропатчен")
    for p, text in writes.items():
        rel = p.relative_to(repo)
        if dry:
            say("dry", f"изменил бы {rel}")
        else:
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text(text, encoding="utf-8")
            say("ok", f"записан {rel}")
    return 0


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("horizon", type=Path, help="путь к чекауту horizon-rust/horizon")
    ap.add_argument("--dry-run", action="store_true", help="только показать, что изменится")
    args = ap.parse_args()
    try:
        return patch(args.horizon.resolve(), args.dry_run)
    except Fail as e:
        say("FAIL", str(e))
        return 2


if __name__ == "__main__":
    sys.exit(main())
