package dev.horizonport

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import kotlin.concurrent.thread

/** Launcher screen: shows whether the game data is there, imports it, starts the game. */
class SetupActivity : Activity() {

    private val ui = Handler(Looper.getMainLooper())
    private lateinit var status: TextView
    private lateinit var progressText: TextView
    private lateinit var importButton: Button
    private lateinit var playButton: Button
    private lateinit var distanceLabel: TextView
    private lateinit var distanceBar: SeekBar

    @Volatile
    private var importing = false

    private val prefs by lazy { getSharedPreferences("horizon", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val pad = (16 * resources.displayMetrics.density).toInt()
        val column = LinearLayout(this)
        column.orientation = LinearLayout.VERTICAL
        column.setPadding(pad, pad, pad, pad)

        status = TextView(this)
        status.textSize = 16f

        importButton = Button(this)
        importButton.text = getString(R.string.import_data)
        importButton.setOnClickListener { pickFolder() }

        progressText = TextView(this)
        progressText.textSize = 14f

        distanceLabel = TextView(this)
        distanceLabel.textSize = 16f

        distanceBar = SeekBar(this)
        distanceBar.max = MAX_DISTANCE - MIN_DISTANCE
        distanceBar.progress = prefs.getInt("renderDistance", DEFAULT_DISTANCE) - MIN_DISTANCE
        distanceBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar?, value: Int, fromUser: Boolean) {
                updateDistanceLabel()
            }

            override fun onStartTrackingTouch(bar: SeekBar?) {}

            override fun onStopTrackingTouch(bar: SeekBar?) {}
        })

        playButton = Button(this)
        playButton.text = getString(R.string.play)
        playButton.setOnClickListener { play() }

        column.addView(status)
        column.addView(importButton)
        column.addView(progressText)
        column.addView(distanceLabel)
        column.addView(distanceBar)
        column.addView(playButton)

        val scroll = ScrollView(this)
        scroll.addView(column)
        setContentView(scroll)

        updateDistanceLabel()
        refresh()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun renderDistance(): Int = MIN_DISTANCE + distanceBar.progress

    private fun updateDistanceLabel() {
        distanceLabel.text = getString(R.string.render_distance, renderDistance())
    }

    private fun refresh() {
        val root = DataImporter.dataRoot(this)
        val ready = DataImporter.isReady(root)
        status.text = getString(
            if (ready) R.string.status_ready else R.string.status_missing,
            root.absolutePath,
        )
        playButton.isEnabled = ready && !importing
        importButton.isEnabled = !importing
    }

    @Suppress("DEPRECATION")
    private fun pickFolder() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE)
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        startActivityForResult(intent, REQ_TREE)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_TREE || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        try {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: Exception) {
            // The grant for this activity is enough for a copy that starts right away.
        }
        startImport(uri)
    }

    private fun startImport(tree: Uri) {
        importing = true
        refresh()
        val root = DataImporter.dataRoot(this)
        thread(name = "horizon-import") {
            val result = try {
                DataImporter.importTree(this, tree, root) { line -> ui.post { progressText.text = line } }
            } catch (e: Exception) {
                "Ошибка: " + (e.message ?: e.javaClass.simpleName)
            }
            ui.post {
                importing = false
                progressText.text = result
                refresh()
            }
        }
    }

    private fun play() {
        val root = DataImporter.dataRoot(this)
        val distance = renderDistance()
        prefs.edit().putInt("renderDistance", distance).apply()
        DataImporter.writeLaunchArgs(root, distance)
        startActivity(Intent(this, HorizonActivity::class.java))
    }

    companion object {
        private const val REQ_TREE = 1001
        private const val MIN_DISTANCE = 4
        private const val MAX_DISTANCE = 16
        private const val DEFAULT_DISTANCE = 8
    }
}
