package dev.horizonport

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

/** Data-folder handling for the launcher screen. Must agree with `android_glue.rs`. */
object DataImporter {

    /** The same folder the native side uses: getExternalFilesDir(null), else filesDir. */
    fun dataRoot(ctx: Context): File = ctx.getExternalFilesDir(null) ?: ctx.filesDir

    /** `.local/horizon-client/<version>` with the prepared resources, if it exists and is not empty. */
    fun resourcesDir(root: File): File? {
        val base = File(root, ".local/horizon-client")
        val versions = base.listFiles { f -> f.isDirectory && (f.list()?.isNotEmpty() == true) }
        return versions?.maxByOrNull { it.name }
    }

    fun isReady(root: File): Boolean = resourcesDir(root) != null

    /** `launch-args.txt` is read by the native side instead of the (empty) command line. */
    fun writeLaunchArgs(root: File, renderDistance: Int) {
        val res = resourcesDir(root) ?: File(root, ".local/horizon-client/26.3")
        val text = buildString {
            appendLine("# Written by the launcher screen on every start. One argument per line.")
            appendLine("--resources")
            appendLine(res.absolutePath)
            appendLine("--render-distance")
            appendLine(renderDistance.toString())
        }
        root.mkdirs()
        File(root, "launch-args.txt").writeText(text)
    }

    private class Entry(val id: String, val name: String, val mime: String?, val size: Long) {
        val isDir: Boolean get() = mime == DocumentsContract.Document.MIME_TYPE_DIR
    }

    private class Progress(private val onProgress: (String) -> Unit) {
        var seen = 0
        var copied = 0
        var skipped = 0
        var bytes = 0L
        private var last = 0L

        fun report(force: Boolean = false) {
            val now = System.currentTimeMillis()
            if (force || now - last > 400) {
                last = now
                onProgress("Файлов: $seen, скопировано: $copied, уже было: $skipped, ${bytes shr 20} МБ")
            }
        }
    }

    private fun children(ctx: Context, tree: Uri, docId: String): List<Entry> {
        val uri = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
        val cols = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE,
            DocumentsContract.Document.COLUMN_SIZE,
        )
        val out = ArrayList<Entry>()
        ctx.contentResolver.query(uri, cols, null, null, null)?.use { c ->
            while (c.moveToNext()) {
                val name = c.getString(1) ?: continue
                val size = if (c.isNull(3)) -1L else c.getLong(3)
                out.add(Entry(c.getString(0), name, c.getString(2), size))
            }
        }
        return out
    }

    private fun displayName(ctx: Context, tree: Uri, docId: String): String? {
        val uri = DocumentsContract.buildDocumentUriUsingTree(tree, docId)
        val cols = arrayOf(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
        ctx.contentResolver.query(uri, cols, null, null, null)?.use { c ->
            if (c.moveToFirst()) return c.getString(0)
        }
        return null
    }

    /**
     * Copies the picked folder into [root], working out where it sits in the
     * `.local/horizon-client/<version>` layout. Returns a human-readable result.
     */
    fun importTree(ctx: Context, tree: Uri, root: File, onProgress: (String) -> Unit): String {
        val rootId = DocumentsContract.getTreeDocumentId(tree)
        val top = children(ctx, tree, rootId)
        val pickedName = displayName(ctx, tree, rootId) ?: ""

        val local = top.firstOrNull { it.isDir && it.name == ".local" }
        val sourceId: String
        val dest: File
        when {
            local != null -> {
                sourceId = local.id
                dest = File(root, ".local")
            }
            top.any { it.isDir && it.name == "horizon-client" } -> {
                sourceId = rootId
                dest = File(root, ".local")
            }
            pickedName == "horizon-client" -> {
                sourceId = rootId
                dest = File(root, ".local/horizon-client")
            }
            else -> return "В выбранной папке нет .local/horizon-client. Выберите папку .local " +
                "(или папку, в которой она лежит)."
        }

        val progress = Progress(onProgress)
        copyDir(ctx, tree, sourceId, dest, progress)
        progress.report(force = true)
        return if (isReady(root)) {
            "Готово. Скопировано файлов: ${progress.copied}, уже было: ${progress.skipped}."
        } else {
            "Скопировано, но .local/horizon-client/<версия> не найден. Проверьте выбранную папку."
        }
    }

    private fun copyDir(ctx: Context, tree: Uri, docId: String, dest: File, st: Progress) {
        if (!dest.isDirectory && !dest.mkdirs()) throw IOException("Не могу создать папку ${dest.path}")
        for (e in children(ctx, tree, docId)) {
            val name = e.name
            if (name == "." || name == ".." || name.contains('/') || name.contains('\\')) continue
            val target = File(dest, name)
            if (e.isDir) {
                copyDir(ctx, tree, e.id, target, st)
            } else {
                copyFile(ctx, DocumentsContract.buildDocumentUriUsingTree(tree, e.id), target, e.size, st)
            }
        }
    }

    private fun copyFile(ctx: Context, src: Uri, dest: File, size: Long, st: Progress) {
        st.seen++
        if (size >= 0 && dest.isFile && dest.length() == size) {
            st.skipped++
            st.report()
            return
        }
        val tmp = File(dest.path + ".part")
        val input = ctx.contentResolver.openInputStream(src)
            ?: throw IOException("Не удалось открыть ${dest.name}")
        input.use { i -> FileOutputStream(tmp).use { o -> st.bytes += i.copyTo(o, 1 shl 20) } }
        if (dest.exists()) dest.delete()
        if (!tmp.renameTo(dest)) throw IOException("Не удалось сохранить ${dest.name}")
        st.copied++
        st.report()
    }
}
